public class ShoppingCart02 {
    public static void main(String[] args) {
        String custName = "Alex";
        String itemDesc = "Shirt";
        String message = custName+" wants to purchase a " + itemDesc;
        
        // Declare and initialize numeric fields: price, tax, quantity.   
        double price = 19.99;
        double tax = 2.45;
        int quanity = 1;
        
        
        
        
        // Declare and assign a calculated totalPrice
        
        double totalPrice = 22.44;
        
        // Modify message to include quantity 
        
        System.out.println(custName + " wants to purchase "+ quanity + " " + itemDesc);
        
        // Print another message with the total cost
        
        System.out.println("The total cost with tax is $"+ totalPrice);
        
    }    
}
