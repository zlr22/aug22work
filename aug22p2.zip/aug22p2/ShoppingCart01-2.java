public class ShoppingCart01 {
    public static void main(String[] args) {
        String custName = "Gary";
        String itemDesc = "Pants";
        
        System.out.println(custName + " wants to buy " + itemDesc);
        
    }
}